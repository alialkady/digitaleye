 var x;
    function r1(){
        document.write("<h1 id='r'> You might have Conjunctival  chemosis</h1> <br><br><h1 id ='c'> Effective  treatment: cold compresses-chilled artificial tears -steroid eye drops.</h1>")
     window.r.style.color="brown";
    window.c.style.color = "blue";
    
    }
        function rr(){
            document.write("<h1 id='r2'>You might have Infective viral and bacterial conjunctivitis</h1> <br><br><h1 id = 'c1'> Effective treatment: you must ask a doctor. Your doctor may prescribe an antibiotic, usually given topically as eye drops or ointment. You shouldn’t touch anyone; it is very contagious. Antibiotics may help shorten the length of infection, reduce complications, and reduce the spread to others</h1>")
        window.r2.style.color = "brown";
            window.c1.style.color = "blue";
        }
        function a(){
            document.write("<h1 id ='a1' >You might have Conjunctival xerosis </h1><br><br><h1 id='a2'>Effective treatment: vitamin A. It is associated with vitamin A deficiency </h1> ")
            window.a1.style.color = "brown";
            window.a2.style.color = "blue";
            
        }
        function b(){
            document.write("<h1 id ='b1'>You might have Sub-conjunctival haemorrhage</h1> <br><br><h1 id = 'b2'> Effective treatment: Subconjunctival hemorrhage doesn’t require treatment. Artificial tears (eye drops) can help relieve eye irritation if it occurs. Most broken blood vessels heal within 2 weeks</h1>");
            window.b1.style.color =  "brown";
            window.b2.style.color =  "blue";
        
        
        
        }
        function c(){
            document.write("<h1 id = 'c1'>You have Allergic conjunctivitis</h1> <br><br> <h1 id ='c2'> Effective treatment: Allergic conjunctivitis can be treated with a variety of medications, including topical <span id='c3'>antihistamines</span>, mast cell stabilizers, nonsteroidal anti-inflammatory drugs (NSAIDs), and corticosteroids</h1>");
            window.c1.style.color = "brown";
            window.c2.style.color = "blue";
            window.c3.style.color = "green";
            
        }
        function d(){
            document.write("<h1 id='d1'>You have Glaucoma</h1> <br><br>  <h1 id='d2'>Effective treatment: Doctors use a few different types of treatment for glaucoma, including medicines (usually eye drops), laser treatment, and if  they do not work, your doctor might suggest surgery</h1>");
            window.d1.style.color = "brown";
            window.d2.style.color = "blue";
            
            
        }
        function e(){
            document.write("<h1 id='e1'>You have Cataract</h1> <br><br><h1 id = 'e2'> Effective treatment: <span id ='e3'>Cataract surgery</span>, it involves removing the clouded lens and replacing it with a clear artificial lens.</h1>");
            window.e1.style.color = 'brown';
            window.e2.style.color = 'blue';
            window.e3.style.color = 'green';
            
        }
        function f(){
            document.write("<h1 id ='e1'>You have Corneal abrasion  Do not warry, it will heal in <span id ='e2'>24 to 72 hours</span> </h1>");
            window.e1.style.color = "brown";
            window.e2.style.color = "green";
            
            
        }
        function e(){
            document.write("<h1 id= 'e1'>you have Myopia (It is a condition when a person can see nearby objects clearly but can not see distant objects)</h1> <br><br> <h1 id='e2'>The treatment: Myopia can be corrected by using concave lens of suitable power</h1>");
            window.e1.style.color = "brown";
            window.e2.style.color = "blue";
             }
        function g(){
            document.write("<h1 id='g1'>you have Hypermetropia  (It is a condition in which the person can see distant objects clearly but is unable to see the nearby objects distinctly)</h1><br><br><h1 id='g2'>The treatment: Hyperopia is corrected by the use of a convex lens of suitable power</h1>");
            
            window.g1.style.color = "brown";
            window.g2.style.color = "blue";
        }
        function h(){
            document.write("<h1 id='h4'>you have Astigmatism (A person suffering from astigmatism has blurred, distorted or fuzzy vision)</h1><br><br><h1 id='h5'> The treatment: Astigmatism is corrected by the use of a cylindrical lens in the spectacles </h1>");
            window.h4.style.color= 'brown';
            window.h4.style.color= 'blue';
            
        }